import React from "react";
import "./App.css";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Home from "./Pages/Home";
import Login from "./Components/Auth-Components/Login";
import Regitraion from "./Components/Auth-Components/Registration";
function App() {
  return (
    <div className="bg-red">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/Registration" element={<Regitraion />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
